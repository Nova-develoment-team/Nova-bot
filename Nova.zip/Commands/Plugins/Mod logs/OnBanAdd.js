module.exports = {
  type: "banAddCommand",
  channel: "$getServerVar[modlogschannel]",
  code: `


`,
};
