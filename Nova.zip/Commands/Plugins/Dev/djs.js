module.exports = {
  name: "djs",
  code: `
  $title[Discord.js Evaluation]
  $author[$userTag[$authorID];$authorAvatar]
  $description[
  $addField[📤 Output:;\`\`\`js
  $djsEval[(async () => {
  try {
      return $message
  } catch (error) {
      return error
  }})();yes]\`\`\`;yes]
  $addField[📥 Input:;\`\`\`js
  $message\`\`\`;yes]
  ]
  $color[BLUE]
  $addTimestamp
  $onlyForIDs[$botOwnerID;870441674525012018;715350994678055004;746295959251583048;714821119080923177;YOur not the owner]
  $suppressErrors
  `,
};
