module.exports = {
  name: "eval",
  aliases: ["aoi", "ev"],
  code: `
$eval[$message;yes]
$deleteCommand
$onlyForids[$botownerid;870441674525012018;715350994678055004;746295959251583048;843536174726512642;only my  owners may use this command]`,
};
