/*module.exports = ({
    type: "loopCommand",
    code: `

    $editmessage[1012934979111616592;{description: <:Cpu:1010186360390418452> CPU: $cpu \n <:ram:1010186363267731506> ram: $rammb \n <a:4267above:968910685599858758> Uptime: $uptime \n <:ping:968910683343310878> ping: $Pingms\n <:ping:968910683343310878> db ping: $dbpingms \n }{color:BLUE};966305408576786524]
    `,
    executeOnStartup: true,
    every: 30000
    })
  */
