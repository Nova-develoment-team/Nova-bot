module.exports = {
  type: "awaitedCommand",
  name: "help-invite",
  code: `$title[<:s_invite:960755956449415168> Nova invite]
$description[user-invites ¦ See user invites
reset-invites ¦ Reset a users invites]
$color[$getServerVar[color]]
$log[[DEBUG] :: $username, used the invite system help category command]`,
};
