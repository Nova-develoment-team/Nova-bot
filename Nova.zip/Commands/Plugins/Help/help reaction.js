module.exports = {
  type: "awaitedCommand",
  name: "help-reaction",
  code: `$title[😁 Nova reaction]
$description[rrole ¦ Add new reaction role]
$color[$getServerVar[color]]
$log[[DEBUG] :: $username, used the reaction help category command]`,
};
