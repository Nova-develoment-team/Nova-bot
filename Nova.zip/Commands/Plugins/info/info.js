module.exports = {
  name: "info",
  code: `
    $description[
    

    $addfield[✨ Developers ✨;
    \`\`\`\    Duckey#4200 - Lead dev
    $usertag[852908598664364082] - Dev 
    $usertag[588671250172477451] - Dev
    $usertag[772756852571766795] - Dev
    $usertag[843536174726512642] - System admin
    $usertag[821484624055894056] - Artist
    $usertag[800886153783279658] - Artist\`\`\`\]

    $addfield[✨ Providers ✨;
    \`\`\`\
    Luxxy hosting - Multi host
    Thermal hosting - Partner
    Artioms hosting - db host + some server for global lavalink
    \`\`\`\]

    
    ]

    $color[PURPLE]`,
};
