module.exports = {
  name: "temprole",
  code: `$channelSendMessage[$channelID;<@$mentioned[1]>, I removed the $roleName[$findRole[$message[2]]] role, time's up]
    $takeRoles[$mentioned[1];$findRole[$message[2]]]
    $wait[$replaceText[$replaceText[$checkCondition[$message[3]==];true;24d];false;$message[3]]]
    $channelSendMessage[$channelID;{description::white_check_mark: | $username[$mentioned[1]]#$discriminator[$mentioned[1]] has been given the $roleName[$findRole[$message[2]]] role. For \`$replaceText[$replaceText[$checkCondition[$message[3]==];true;undefined time];false;$message[3]]\`}{color:RANDOM}]
    $giveRoles[$mentioned[1];$findRole[$message[2]]]
    $suppressErrors[{title:An error occured}{description:Looks like I can't find the role}{color:RED}]
    $onlyIf[$rolePosition[$highestRole[$clientID]]<$rolePosition[$highestRole[$mentioned[1]]];That user is higher than me on role position]
    $onlyIf[$rolePosition[$highestRole[$authorID]]<$rolePosition[$highestRole[$mentioned[1]]];That user is higher than you on role position.]
    $argsCheck[>3;Incorrect arguments. Example: temprole @user @role]
    $onlyPerms[manageroles;{title:Missing Permissions}{color:RANDOM}{description:You don't have \`MANAGE_ROLES\` permissions to use this command}]`,
};
