61 path=Commands/Plugins/💰Economy/chest-open/opendaily.js
