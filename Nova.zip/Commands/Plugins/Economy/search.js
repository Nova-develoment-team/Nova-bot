module.exports = {
  name: "search",
  code: `$setGlobalUserVar[Wallet;$sum[$getGlobalUserVar[Wallet;$authorID];$random[20;60]];$authorID]
    $setGlobalUserVar[XP;$sum[$getGlobalUserVar[XP;$authorID];$random[1;5]];$authorID]
    $title[Search]
    $thumbnail[$userAvatar[$authorID]]
    $color[$getServerVar[color]]
    $description[$username, $randomText[you looked under the welcome mat.;you went searching thru your mom's purse while she was asleep.;you're hungry so you decided to search thru the dumpster behind the Subway.;you searched your dads truck very thoroughly.;your friends came over and when one of them went to the bathroom, you searched thru his coat pockets.]
    ]
    $footer[💵 +$$random[20;60] | 🗡 +$random[1;5]xp]
    $globalCooldown[35s;Looking for a little loose change? You're going to have to try again in %time%]`,
};
