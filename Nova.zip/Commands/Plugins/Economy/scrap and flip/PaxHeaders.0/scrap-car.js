65 path=Commands/Plugins/💰Economy/scrap and flip/scrap-car.js
