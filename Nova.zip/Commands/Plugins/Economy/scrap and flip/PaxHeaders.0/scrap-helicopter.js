72 path=Commands/Plugins/💰Economy/scrap and flip/scrap-helicopter.js
