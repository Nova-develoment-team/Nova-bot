/*
module.exports = ({
type: "onGuildJoin",
channel: "$systemChannelId",
code: `$log[Joined $servername now in $serverCount, previous $get[old]]
$let[old;$servercount]
$description[Hello! I am nova, a bot with $commandsCount and 12 categorys, i have many fun things for you and your server :D]
$color[GREEN]`
})
*/
