module.exports = {
  keys: [
    process.env.key1, //private key
    process.env.key2, //testing key
    process.env.key3, //admin key
    process.env.key4, // Owner Key
    process.env.key5, // api key
    process.env.key6 // api trial key
  ],
};