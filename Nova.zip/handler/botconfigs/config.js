require("dotenv").config();

module.exports = {
  Bot: {
    token:
      process.env.token,
    prefix: ["$GetServerVar[prefix]", "<@$clientID>"],
      intents: "all",
    sharding: true,
      shardAmount: "10"
  },

  webhooks: {
    url: process.env.hook
  },

  bot_settings: {
  ownerid: "845312519001342052",
    path: "/Nova bot/Nova/"
  },
  events: {
    antiCrash: true,
    autoUpdate: false,
  },

  respondOnEdit: {
    commands: true,
  },
  debug: {
    iplogging: true,
    interpreter: true,
  },

  suppressAllErrors: {
    errorMessage: [
      "",
      "$log[[ERROR] :: $username had a error in $servername | ERROR ID: $randomString[$random[4;10]]]{newEmbed:{title:Ah oh!}{description:There was a error | ERROR ID: $randomString[$random[4;10]]}{color:fcbfcb}}",
    ],
  },

  lava_settings: {
    node_1: process.env.lavalink_host /*The lavalink host, Should not add https:// or http:// */,
    Host_password: process.env.lavalink_password /* The lavalinkd host password */,
  },

  website_settings: {
    title: process.env.title,
    domain: process.env.website_domain,
    Maintnance: false,
    bg: "https://cdn.nova-bot.tk/chrome_s9GZjpKOvb.png/direct",
  },

  dash_settings: {
    id: "1046016653269418075",
    secret: process.env.bot_secret
  },
  
  db_settings: {
    db_uri: process.env.db_uri,
  }
};

