module.exports = {
  userav: "0",
  //music
  file: "index.js", //For reboot and stats//
  database: "./database/main/main_scheme_1.sql", //For stats//

  pause: "⏸️ Paused.",
  resume: "▶️ Resumed!",
  skip: "⏩ Skipped!", //Available {song}//
  stop: "⏹ Stopped.",
  remove: "Removed song on {d-amount}.",
  loop: "➿ looped", //Available {d-amount}//
  botinfo: "",
  purge: "",
  afk: "",
  uptime: "",
  help: "",

  clearsong: "✅ Cleared queue. from **{amount} song** to **0**", //Available {amount}//
  shuffle: "Shuffle Queue.",
  errorjoin: "{title:❌ You're not in a voice channel.} {color:#2f3136}",
  errorqueue: "{title:❌ There no song was playing.} {color:#2f3136}",

  join: "Joined Voice Channel to the {join}.", //Available {join}//
  dc: "Disconnected.",

  //Changing Other//
  clientidsoundcloud: "7g7gIkrcAS05cJVf2FlIsnkOXtg4JdSe",
  color: "#2f3136",
  permission: "2176183360",
  userid: "default",
  logmusic: "0",
  247: "0", //0 = off | 1 = on stay 2 minutes | 2 = stay 24/7//
  channelstatus: "895990877888053268", //Change to your channel id, to send message when the bot restart.//
  vol: "50", //Default Volume//
  maxvol: "150", //Max Volume//
  last: "null",
  linkdownload: "",
  filters: "none",
  controlreact: "0",
  saveseek: "0",
  durationcache: "0",
  reactmessageid: "",
  nontrigger: "0", //for disable play message when react active//

  customemoji1:
    "https://media.discordapp.net/attachments/910427322346270770/910811673076580362/playing.gif",
  ytemoji:
    "https://images-ext-2.discordapp.net/external/TFmOpQvHM7JVOYjW1IZS_KT75aS8FloHDRngInNrjpA/%3Fsize%3D96/https/cdn.discordapp.com/emojis/907192242907783198.png",
  scemoji: "https://cdn.discordapp.com/emojis/907192307110019072.png?size=96",

  userused: "0",
  commanduserused: "0",

  //For playlist//
  1: "",
  2: "",
  3: "",
  4: "",
  5: "",
  6: "",
  7: "",
  8: "",
  9: "",
  10: "",
  no: "❌",
  hint: "2",
  guess: "0",
  msg: "0",
  yes: "✅",
  join: "",
  up: ">",
  prefix: ">",
  wtitle: "",
  wmsg: "",
  wimg: "",
  wchannel: "",
  wdm: "disabled",
  autorole: "",
  imageauthor: 0,
  imageresult: "",
  imagelength: 0,
  imagenumber: 0,
  imagepage: 1,
  bleft: "left|890706435955101747|false",
  bright: "right|890706436278079499|false",
  bno: "guilded_image_3833dadf524f7034bf|890299986695307374|false",
  warn: "0",
  mute: "",
  levelling: "false",
  level_msg: "{user.mention}, you just levelled up to {level}!",
  level_channel: "",
  level_roles: "",
  level_order: "",
  exp: "0",
  level_card: "https://cdn.nova-bot.tk/5ynk5an5.jpg",
  level_msges: "",
  level_morder: "",
  req: "100",
  rank: "0",
  snipe_msg: "",
  snipe_author: "",
  snipe_channel: "",
  snipe_date: "",
  msgEditorID: "undefined",
  esnipeOldMsg: "undefined",
  antilink: "false",
  giveawaychannelid: 0,
  giveawayguildid: 0,
  giveawayprize: "",
  giveawaydescription: "",
  giveawaytime: 0,
  giveawayparticipants: "",
  giveawayisfinished: "false",
  giveawayisgiveaway: "false",
  testid1: "",
  premium: "false",
  premiumcode: "",
  premiumcode6m: "",
  premiumcode1y: "",
  simbol: "<:money:912633237233360917>", //Wallet
  bank: "0", //Bank
  work_msges: "", //Possible work messages
  work_amounts: "", //Possible work amounts
  work_cd: "10m", //Cooldown for work
  symb: "<:money:912633237233360917>", //Money symbol
  bs: "<:money:912633237233360917> ", //Bank symbol
  sb: "0", //Starting Bal
  sbd: "false", //Starting Claimed or no
  rs: "false", //Random spawns
  ra: "", //Spawn amounts
  rc: "", //Spawn blacklisted channels
  e: "false", //Economy Enabled Or no
  bc: "1000000", //Maximum bank capacity
  cf: "0", //Cock fight chances
  c: "0", //Chicken count
  cc: "0", //Chicken Cost
  gc: "0", //Max gamble cost for RPS, Roulette and CF
  ru: "", //Blacklisted economy users
  afk_roles: "", //AFK needed roles
  r: "", //Reason for AFK
  time: "", //Time for AFK
  afk_pings: "0", //Pings count in AFK
  afk_mentions: "", //Mentions by which user in AFK
  //Bot Logs
  bl: "", //Bot Logs channel
  afk: "",
  EnglishOnly: "off",
  welcomeBg: "",
  welcomeChannel: "",
  welcomeMsg: "",
  verify: "on",
  verifchannel: "900721610313584650",
  verifrole: "900429109933535292",
  cbw: "",
  ticketchannel: "",
  endstamp: "0",
  hoster: "",
  prize: "",
  joined: "0",
  joinedusers: "",
  ended: "false",
  item: "heh", //Item names
  roles: "heh",
  names: "heh", //Role shop messages
  tmid: "a",
  tmc: "",
  tmm: "",
  tm: "",
  tc: "",
  to: "",
  t: "",
  badwords: "0",
  beg: "",
  XP: "0",
  Bank: "0",
  Wallet: "0",
  psuffix: "0",
  tv: "0",
  duffle: "0",
  bag: "0",

  smartphone: "0",
  laptop: "0",
  car: "0",
  truck: "0",
  helicopter: "0",
  apartment: "0",
  house: "0",
  mansion: "0",
  DailyChest: "0",
  lucky: "0",
  spiteful: "0",
  PoorBadge: "0",
  RichBadge: "0",
  MillionerBadge: "0",
  BillionaireBadge: "0",
  shovel: "0",
  fishingpole: "0",
  fish: "0",
  legendery: "0",
  exotic: "0",
  rare: "0",
  duckey: "0",
  spinner: "0",
  pp: "0",
  gun: "0",
  dirt: "0",
  pickaxe: "0",
  stone: "0",
  plant: "0",
  Blacklist: "false",
  slotbet: "0",
  birb_food: "0",
  birb_water: "0",
  birb: "0",
  birb_sleep: "100",
  birb_name: "birby",
  birb_hungry: "100",
  birb_thirst: "100",
  birb_love: "100",
  xpsimbol: "<a:Xp:913261556312191036> ",
  godpickaxe: "0",
  godpick: "0",
  goldkey: "0",
  godgem: "0",
  abcdefg: "0",
  wooden_pickaxe: "0",
  pickaxe1: "false",
  pickaxe11: "false",
  pickaxe111: "false",
  pickaxe1111: "false",
  iron_pickaxe: "1",
  gold_pickaxe: "0",
  diamond_pickaxe: "0",
  iron_ore: "0",
  bronze_ore: "0",
  gold_ore: "0",
  diamond_ore: "0",
  wood_durability: "10",
  iron_durability: "15",
  gold_durability: "20",
  diamond_durability: "25",
  teaminfo: "/////////////",
  team: "",
  teamid: "0",
  reqid: "",
  Req1: "",
  Req2: "",
  Req3: "",
  Req4: "",
  Req5: "",
  Req6: "",
  Req7: "",
  Req8: "",
  Req9: "",
  Req10: "",
  Req11: "",
  Req12: "",
  Req13: "",
  rare: "0",
  xpp: "0",
  reacted: "true",
  mars: "0",
  joker: "0",
  slotbet: "0",
  double: "0",
  dank: "0",
  mbt: "normal",
  common: "0",
  bag: "0",
  uncommon: "0",
  majestic: "0",
  bee: "0",
  bchick: "0",
  chipmunk: "0",
  hlizard: "0",
  hsnake: "0",
  hsquid: "0",
  ssimbol: "https://cdn.discordapp.com/emojis/909868786591596634.gif?size=44",
  future: "0",
  promocodes: "ujfhfhfgjfdfdfjdgfgfofgigjk",
  nature: "0",
  green: "0",
  req: "100",
  rank: "0",
  day: "false",
  beg: "",
  cat: "0",
  robber: "0",
  cow: "0",
  ticket: "0",
  gun1: "false",
  evil: "0",
  zebra: "0",
  gun: "0",
  useless: "0",
  say: "",
  messageid: "",
  utils: "https://cdn.discordapp.com/emojis/904340351999959101.png?size=128",
  xppp: "https://cdn.discordapp.com/emojis/904340614030716988.png?size=128",
  homo: "https://cdn.discordapp.com/emojis/904340978264068098.png?size=128",
  vip: "0",
  promochan: "904319380312191026",
  bought1: "false",
  promocode: "",
  badge4: "empty",
  badge5: "empty",
  match: "",
  channel: "",
  user: "",
  chat: "false",
  title1: "empty",
  title2: "empty",
  title3: "empty",
  titlev1: " ",
  titlev2: " ",
  titlev3: " ",
  pray: "true",
  t1: "false",
  t2: "false",
  t3: "false",
  t4: "false",
  t5: "false",
  wbage: "true",
  passive: "false",
  bought2: "false",
  bought3: "false",
  badge1: "empty",
  badge2: "empty",
  badge3: "empty",
  lotto: "false",
  trophy: "0",
  esimbol: "<:money:912633237233360917>",
  lot: "false",
  banklimit: "250000",
  prem: "false",
  ccmd: "",
  ubj: "0",
  nptrue: "true", //music: prune activation

  // ===== MISCELLANEOUS ===== //

  chatbottrue: "false", //misc: chatbot AI activation
  botbj: "0",
  i1: "0",
  i1: "0",
  i2: "0",
  i3: "0",
  i4: "0",
  i5: "0",
  i6: "0",
  i7: "0",
  i8: "0",
  bjbet: "0",
  diamond: "0",
  stone: "0",
  banknote: "0",
  iron: "0",
  pickaxe: "0",
  cdes: "",
  gem11: "0",
  gem22: "0",
  premi: "0",
  sreq: "0", //Starboard Req
  schannel: "", //Starboard Channel
  smid: "", //Message IDs
  semid: "", //Message to be edited on more reactions
  author: "", //Author of the message
  antispam: "false", //Anti Spam
  pw: "", //Prohibited Words
  caps: "false", //Anti All Caps
  massmention: "false", //Mass Mention
  massemoji: "false", //Mass Emoji
  spammessages: "0", //User Spam Messages
  antilink: "false", //Anti Links
  afk_roles: "", //AFK needed roles
  r: "", //Reason for AFK
  time: "", //Time for AFK
  afk_pings: "0", //Pings count in AFK
  afk_mentions: "", //Mentions by which user in AFKl}!",
  hoster: "",
  prize: "",
  joined: "0",
  joinedusers: "",
  ended: "false",
  lasere: "false",
  weekly: "false",
  lase: "1",
  chand: "0",
  plant: "0",
  cash: "500",
  gem1on: "off",
  gem2on: "off",
  premium: "false",
  bank: "1500",
  chest: "0",
  roles: "",
  emoji: "",
  afk: "",
  reason: "",

  mrole: "", //Original Mute Role
  //Warns
  wc: "0", //Warn Count
  reason: "", //Warn Reasons
  //nuke
  nc: "", //Nuke Channel
  //afk
  afk_roles: "", //AFK needed roles
  r: "", //Reason for AFK
  time: "", //Time for AFK
  afk_pings: "0", //Pings count in AFK
  afk_mentions: "", //Mentions by which user in AFK
  //Bot Logs
  bl: "", //Bot Logs channel
  money: "0", //Wallet
  bank: "0", //Bank
  work_msges: "", //Possible work messages
  work_amounts: "", //Possible work amounts
  work_cd: "10m", //Cooldown for work
  symb: "<:Gcred:897938380543901756>", //Money symbol
  bs: "<:Gcred:897938380543901756>", //Bank symbol
  sb: "0", //Starting Bal
  sbd: "false", //Starting Claimed or no
  rs: "false", //Random spawns
  ra: "", //Spawn amounts
  rc: "", //Spawn blacklisted channels
  e: "false", //Economy Enabled Or no
  bc: "50000", //Maximum bank capacity
  cf: "0", //Cock fight chances
  c: "0", //Chicken count
  cc: "0", //Chicken Cost
  gc: "500000", //Max gamble cost for RPS, Roulette and CF
  ru: "", //Blacklisted economy users
  //Suggestions
  sc: "0", //Suggestions channel
  so: "", //Suggestions order
  no: "", //Numbers order
  sch: "", //Suggestions channel
  //Tags
  tags: "", //First message tag
  reply: "", //First message reply
  mtags: "", //Mention message tag
  mreply: "", //Mention message reply
  ctags: "heh", //Contains message tag
  creply: "heh", //Contains message reply
  //Role Shops
  roles: "heh", //Roles
  names: "heh", //Role shop messages
  item: "heh", //Item names
  /*================*/
  wallet: 0, //economy: wallet
  bank: 0, //economy: bank
  net: 0, //economy secret
  currency: "💵", //economy: symbol
  min: 50, //economy: minumum payout
  max: 200, //economy: maximum payout
  mkoin: "<:mkoin:855464380907782144>", //economy: global currency (thank you BitShelf-Dev#9999)
  cooldown: "30s", //economy: cooldown
  userbal: "0", //economy: user ballance query

  inv_mkoin: 0, //inventory
  inv_primogem: 0, //inventory

  shop_mkoin: 1, //economy: mKoin price
  shop_primogem: 160, //economy: primogem price

  userbuy: "0", //economy: shop query
  userprice: 0, //economy: chosen item's price
  useritem: "", //economy: chosen item

  // ===== G-ECONOMY ===== //

  gwallet: 0,
  gbank: 0,
  gnet: 0,
  gcurrency: "<:mkoin:895765300413337671>",
  gmin: 50,
  gmax: 200,
  gcooldown: "30s",
  guserbal: "0",
  hex: "#ff4500",
  yes: "<a:yes:895767602071224380>", //dev only: custom emote, tickYes
  no: "<:warn:906325900541444106> ", //dev only: custom emote, tickNo
  on: "<:enabled:872233009171017798>", //dev only: custom emote, switch_on
  off: "<:of:895768764547747900>", //dev only: custom emote, switch_off
  right: "<:arrow_right:869517484192055398>", //dev only: custom emote, arrow_right
  left: "<:arrow_left:869517513929662464>", //dev only: custom emote, arrow_left
  bright: "rightt|895347118213046282|true",
  bleft: "leftt|895347117713948733|true",
  brightskip: "rightt|895347118213046282|true",
  bleftskip: "leftt|895347117713948733|true",

  testid1: "0", //dev only: test ID 1
  testid2: "0", //dev only: test ID 2
  testid3: "0", //dev only: test ID 3

  cachetrue: "true", //dev only: caching activation

  channelreboot: "0", //dev only: last moments of Magik.js before he reboots

  // ===== API HAVEN ===== //

  hug: "0", //apih: hug count
  pat: "0", //apih: pat count

  // ===== MISCELLANEOUS B ===== //

  guess: "0", //miscellaneous: guess the number
  hint: "2", //miscellaneous: guess the number, hint
  msg: "0", //miscellaneous: guess the number, msg tracker

  userav: "0", //miscellaneous: user avatar query
  userinf: "0", //miscellaneous: user info query

  imageresult: "", //miscellaneous: image search result
  imagelength: "", //miscellaneous: image search result length
  imagenumber: "0", //miscellaneous: image search result number (array)
  imagepage: "1", //same as above but for pages
  imageauthor: "0", //owo
  imageauthorb: "0", //uwu

  giveawaychannelid: "0",
  giveawayguildid: "0",
  giveawayprize: "",
  giveawaydescription: "",
  giveawaytime: "0",
  giveawayparticipants: "",
  giveawayisfinished: "false",
  giveawayisgiveaway: "false",
  emote: "", //secret: emote.
  emotename: "", //secret: emote name
  emotenewname: "", //secret: emote new name
  emoteid: "", //secret: emote id
  emoteimg: "", //secret: emote image link
  emoteguild: "", //secret: emote guild origin
  EnglishOnly: "off",
  no: "❌",
  createrr: "exx",
  Blacklist: "false",
  guild: "894281583526301796",
  emoji: "yess", //Emojis
  orole: "", //Only for role
  brole: "", //Blacklisted roles
  cemoji: "", //Current emoji
  crole: "", //Current role
  corole: "", //Current only for role
  cmid: "", //Current messageid
  cbrole: "", //Current blacklisted role
  arrole: "", //Add RR Role
  aremoji: "yess", //Add RR emoji
  armid: "", //Add RR messageid
  nah: "<:cross:895767564322492488>",
  yeah: "<a:yes:895767602071224380>",
  bl: "",
  invite:
    "https://discord.com/api/oauth2/authorize?client_id=896133866874613820&permissions=8&scope=bot",
  pfp: "https://cdn.discordapp.com/avatars/896133866874613820/a0e67da344cae9abfc29115193e9e0bd.png?size=2048",
  info: "Requested by $username#$discriminator[$authorid]",
  userav: "0",
  delete: "0",
  purge: "0",
  msg1: "",
  author1: "",
  avatar1: "",
  msg2: "",
  author2: "",
  avatar2: "",
  msg3: "",
  author3: "",
  avatar3: "",
  msg4: "",
  author4: "",
  avatar4: "",
  msg5: "",
  author5: "",
  avatar5: "",
  msg6: "",
  author6: "",
  avatar6: "",
  msg7: "",
  author7: "",
  avatar7: "",
  msg8: "",
  author8: "",
  avatar8: "",
  msg9: "",
  author9: "",
  avatar9: "",
  msg10: "",
  author10: "",
  avatar10: "",
  msg11: "",
  author11: "",
  avatar11: "",
  msg12: "",
  author12: "",
  avatar12: "",
  msg13: "",
  author13: "",
  avatar13: "",
  msg14: "",
  author14: "",
  avatar14: "",
  msg15: "",
  author15: "",
  avatar15: "",
  op: "", //Opponent
  hp: "0", //Hitpoint
  lh: "", //Last Hit By
  fmid: "",
  channel_snipe: "",
  author_snipe: "",
  icon_snipe: "",
  message_snipe: "",
  msgEditorID: "undefined",
  esnipeOldMsg: "undefined",
  welcomeChannel: "",
  welcomeMsg: "{user.ping} Welcome to the server",
  file: "main.js", //For reboot and stats//
  database: "./database/main/main_scheme_1.sql", //For stats//

  pause: "⏸️ Paused.",
  resume: "▶️ Resumed!",
  skip: "⏩ Skipped!", //Available {song}//
  stop: "⏹ Stopped.",
  remove: "Removed song on {d-amount}.", //Available {d-amount}//

  clearsong: "✅ Cleared queue. from **{amount} song** to **0**", //Available {amount}//
  shuffle: "Shuffle Queue.",

  join: "Joined Voice Channel to the {join}.", //Available {join}//
  dc: "Disconnected.",

  //Changing Other//
  clientidsoundcloud: "7g7gIkrcAS05cJVf2FlIsnkOXtg4JdSe", //for soun
  permission: "294233959488",
  userid: "default",
  logmusic: "0",
  247: "0", //0 = off | 1 = on stay 2 minutes | 2 = stay 24/7//
  channelstatus: "757831705397559337", //Change to your channel id, to send message when the bot restart.//
  vol: "50", //Default Volume//
  maxvol: "150", //Max Volume//
  last: "null",
  linkdownload: "",
  filters: "none",
  controlreact: "0",
  saveseek: "0",
  durationcache: "0",
  reactmessageid: "",
  nontrigger: "0", //for disable play message when react active//
  scsearch: "0",

  customemoji1:
    "https://cdn.discordapp.com/emojis/852434440668184615.png?size=4096",
  ytemoji: "https://cdn.discordapp.com/emojis/852432148207108110.png?size=4096",
  scemoji: "https://cdn.discordapp.com/emojis/852432173758676993.png?size=4096",
  loademoji:
    "https://cdn.discordapp.com/emojis/895505960427196426.gif?size=4096",

  userused: "0",
  commanduserused: "0",

  //For playlist//
  1: "",
  2: "",
  3: "",
  4: "",
  5: "",
  6: "",
  7: "",
  8: "",
  9: "",
  10: "",

  //for soundcloud non-link
  awaitsc1: "",
  awaitsc2: "",
  awaitsc3: "",
  awaitsc4: "",
  awaitsc5: "",
  welcomeChannel: "",
  welcomeMsg: "{user.ping} Welcome to the server",
  welcomeBg:
    "https://cdn.discordapp.com/attachments/850033801581297755/863810314135011338/blob-scene-haikei.png",
  goodbyeChannel: "",
  goodbyeMsg: "{user.tag} Goodbye, we will miss you",
  goodbyeBg:
    "https://cdn.discordapp.com/attachments/850033801581297755/863810314135011338/blob-scene-haikei.png",
  iron: "<:Irons_brick:913355918463352872>",
  copper: "<:Copper_brick:913355879011725313>",
  pickaxe1: "<:Pickaxe:913356521558130718>",
  dimond: "<:Diamond_brick:913355970753740840>",
  gold: "<:Golden_brick:913355944958767104>",
  dot: "<:dot:913355840927440918>",
  godpick: "<:God_pickaxe:914004227938979921>",
  error: "<:error:914016026600013905>",
  goldenpick: "<:golden_pickaxe:914023858170892319>",
  dimondpickaxe: "<:diamond_pickaxe:914023807839248405>",
  Hearts_left: "<:heart:914372501642051616>",
  antiSwear: "false",
  key: "7122011",
  maxexp: "100",
  welcome_channel: "",
  welcomer: "false",
  code: "",
  //economy
  XP: "0",
  Bank: "0",
  Wallet: "0",
  psuffix: "0",
  tv: "0",
  duffle: "0",
  bag: "0",
  smartphone: "0",
  laptop: "0",
  car: "0",
  truck: "0",
  helicopter: "0",
  apartment: "0",
  house: "0",
  mansion: "0",
  DailyChest: "0",
  lucky: "0",
  spiteful: "0",
  badge1: "blank",
  badge2: "blank",
  badge3: "blank",
  rr: "",
  abm: "",
  abm2: "",
  apikey: "7122011",
  messages: "",
  antiSpam: "false",
  spamLimit: "3",
  commandusersused: "0",
  isread: "false",
  letterTitle: "",
  letterDescription: "",
  modmail_modRoleID: "",
  modmail_adminRoleID: "",
  modmail_channel: "",
  modMailUserID: "",
  modmail_setup: "false",
  channelid: "",
  isModmail: "false",
  modlogschannel: "",
  modlogSetup: "false",
  modlogsEnabled: "false",
  ticketsetup: "false",
  execdatanumber: "0",
  job: "none",
  novaVersion: "0.0.0",
  autoban: "false",
  autoBanLimit: "3",
  yearcode: "YMIXf-CkjRtEN-0gkbH5-bf73GcJR-iX28UdjLe",
  yearcode2: "mwDZ5-fsa4A8N-1hfVhG-b5owjiJd-xZD3pIBqE",
  month: "F2eF0-Xm3sPDl-nKE1xG-LXkzMqEb-nAD1FAxvk",
  month2: "4jomL-8H6RF5B-7qYG33-46wcdApe-WlIRLfbC6",
  month3: "MDey1-cnTwnBQ-UQceHy-3bFhBF52-HyiDkmbdg",

  code2: "qTDpI-Ky2E0uy-7sNDsw-mq9S1oYe-n7CJLSrdI",
  premiumcode3: "U05CR-pU3rQTl-KMIzMH-7hPmezMi-nDvPvxnK4",
  premiumcode4: "FI0x0-WBmcTWc-tgw0hm-TP8O9a28-c37y4og0h",
  premiumcode5: "AV451-GoQ57xE-BtaPDY-RiXsx7V9-Lid16qMZU",
  premiumcode6: "AV441-GoQ57xE-BtaPDY-Ricsx7V9-Lid16qMZU",
  auth: "false",
};
